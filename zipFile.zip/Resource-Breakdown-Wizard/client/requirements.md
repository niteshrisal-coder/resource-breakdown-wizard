## Packages
papaparse | For CSV export functionality
clsx | For conditional class merging (already in base but good to confirm)
tailwind-merge | For conditional class merging (already in base)
lucide-react | For icons (already in base)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
